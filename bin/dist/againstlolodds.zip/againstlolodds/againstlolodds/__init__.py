import urllib3

urllib3.disable_warnings()

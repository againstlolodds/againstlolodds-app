from againstlolodds.app import AgainstLoLOddsApp


def run():
    AgainstLoLOddsApp().run()


if __name__ == '__main__':
    run()
